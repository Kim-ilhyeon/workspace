package com.kh;

public class Variable {
	
	public static void main(String[] args) {
		/*
		 * 변수의 목적?
		 * - 데이터(값)를 저장하기 위한 공간
		 * - 가독성을 증가 ( 변수의 이름을 의미있게 주어야 함!! )
		 * - 재사용성 증가 ( 한번 값을 저장하면 필요할 때마다 변수이름으로 가져다가 사용 )
		 * - 유지보수가 용이 ( 한번 저장해놓으면 해당 위치의 값을 변경 )
		 */
	}
}
